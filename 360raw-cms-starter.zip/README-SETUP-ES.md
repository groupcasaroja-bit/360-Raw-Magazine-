# 360 Raw Magazine — CMS inicial

Este paquete añade la base del panel editorial Decap CMS. **No está conectado ni publicado en tu repositorio todavía.** Para que la portada actual muestre automáticamente los artículos, el sitio también debe leer `content/posts` durante el proceso de build. El HTML original que compartiste es estático y no lo hace por sí solo.

## Archivos incluidos

- `admin/index.html`: entrada del panel en `/admin/`.
- `admin/config.yml`: configuración de artículos, páginas, categorías y carga de imágenes.
- `content/posts/example-article.md`: noticia de ejemplo.
- `content/pages/about.md`: contenido de ejemplo para la página institucional.

## Paso 1 — Identifica el repositorio

Abre GitHub y copia la URL del repositorio conectado a Netlify. En `admin/config.yml`, cambia:

`YOUR_GITHUB_USERNAME/YOUR_REPOSITORY`

por `usuario/repositorio`, sin la URL completa. Confirma también la rama de publicación (`main`, `master` u otra) y actualiza `branch`.

## Paso 2 — Añade los archivos al repositorio

Copia las carpetas `admin/` y `content/` a la raíz del proyecto que Netlify publica. Conserva el HTML y los archivos existentes; no los reemplaces a ciegas.

## Paso 3 — Configura autenticación

El CMS no debe quedar abierto. La configuración de GitHub necesita un flujo OAuth compatible y autorizado para Decap CMS. Configura el proveedor de autenticación/servidor OAuth según la arquitectura actual del proyecto y las instrucciones vigentes de Decap CMS. No pongas un token personal de GitHub en `config.yml`, en el HTML ni en variables expuestas al navegador.

Antes de producción, prueba que una persona sin autorización no pueda entrar y que solo editores aprobados puedan guardar cambios.

## Paso 4 — Integra el contenido con la portada

Este paso es obligatorio. El HTML original tiene titulares y tarjetas escritos directamente dentro de `index.html`; por eso, aunque el CMS guarde un Markdown, la portada no lo mostrará automáticamente.

Hay que adaptar el build del proyecto para:
1. leer `content/posts/*.md`;
2. generar una página por artículo;
3. mostrar los artículos publicados en la portada;
4. excluir borradores;
5. conservar los estilos actuales y generar enlaces permanentes;
6. copiar las imágenes subidas a la ruta pública correspondiente.

El generador (por ejemplo, Eleventy) y el comando de build deben elegirse después de revisar los archivos actuales del repositorio para no romper la publicación existente.

## Paso 5 — Netlify

En el panel de Netlify, confirma el repositorio conectado, la rama de producción y el comando/directorio de build. Tras integrar el generador, realiza un deploy de prueba y comprueba `/admin/`, la creación de un borrador, la publicación, la carga de una imagen y la aparición del artículo en la portada.

## Paso 6 — Lista de comprobación

- [ ] Repositorio y rama correctos
- [ ] Autenticación OAuth configurada y probada
- [ ] `/admin/` accesible solo a editores autorizados
- [ ] Build genera páginas de artículos
- [ ] Portada muestra solo artículos publicados
- [ ] Carga y visualización de imágenes comprobadas
- [ ] SEO básico: título, descripción, URL canónica y Open Graph
- [ ] Prueba en móvil y escritorio
- [ ] Deploy de producción verificado

## Para terminar la integración exacta

Comparte la URL del repositorio GitHub (no contraseñas, tokens ni claves) y, si el repositorio no es público, conecta la integración autorizada de GitHub en ChatGPT. Con los archivos reales del proyecto se puede preparar un cambio preciso para su estructura y comando de build.
